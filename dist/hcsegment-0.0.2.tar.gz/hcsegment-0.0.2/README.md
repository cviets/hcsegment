<h1 align="center">HCSegment</h1>
