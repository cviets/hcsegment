from .modules.denoise import main_denoise

def main(input: str):
    main_denoise(input)